import 'package:bookreadingapp/Screens/Choose_Books.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';


class Launguage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade300,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text("Choose Launguage To Learn", style: TextStyle(fontSize: ScreenUtil().setHeight(34)),
        ),
        centerTitle: false,
      ),
      body: LaunguageBody(),
    );
  }
}

class LaunguageBody extends StatefulWidget {
  @override
  _LaunguageBodyState createState() => _LaunguageBodyState();
}
class _LaunguageBodyState extends State<LaunguageBody> {
  @override
  Widget build(BuildContext context) {
    return GridView.count(
      // Create a grid with 3 columns.
      crossAxisCount: 2,
      children: List.generate(24, (index) {
        return Center(
          child: CupertinoButton(
            child: Column(
              children: <Widget>[
                CircleAvatar(
                  maxRadius: 70.0,
                  backgroundImage: AssetImage('images/launguages/launguage$index.png'),
                ),
                Text("launguage$index", style: TextStyle(fontSize: ScreenUtil().setHeight(24), fontWeight: FontWeight.bold),
                )
              ],
            ),
            onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (context) => ChooseBook()));},
          ),
        );
      }),
    );
  }
}
