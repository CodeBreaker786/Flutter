import 'dart:io';

import 'package:bookreadingapp/Screens/CheckAuth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';


class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  File _image;

  File _cover;
  String emailid="demo@gmail.com";
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  Future getImage(int position) async {
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      if (image != null) {
        if (position == 1) {
          _cover = image;
        } else {
          _image = image;
        }
      }
    });
  }//For Profile Picture of user
  @override
  void initState() {
    FirebaseAuth.instance.currentUser().then((user) => user != null
        ? setState(() {

      emailid=user.email;
    })
        : null);
    super.initState();

  }
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Stack(
            overflow: Overflow.visible,
            children: <Widget>[
              Container(
                  height: ScreenUtil().setHeight(300),
                  width: double.infinity,
                  color: Colors.green,
                  child: _cover != null ? Image.file(_cover, fit: BoxFit.fitWidth,) : Image.asset("images/sa.jpg", fit: BoxFit.fitWidth,)),
              Positioned(
                bottom: ScreenUtil().setHeight(-80),
                right: 20,
                child: CupertinoButton(
                  padding: EdgeInsets.all(0),
                  onPressed: () {
                    getImage(2);
                  },
                  child: CircleAvatar(
                    backgroundImage: _image != null ? FileImage(_image) : AssetImage("images/profile.jpg"),
                    minRadius: ScreenUtil().setHeight(40),
                    maxRadius: ScreenUtil().setHeight(80),
                  ),
                ),
              ),
              Positioned(
                top: 5,
                right: 5,
                child: Container(
                  child: CupertinoButton(
                    onPressed: () {
                      getImage(1);
                    },
                    child: Icon(
                      Icons.edit,
                      size: 20,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Container(
            child: Column(
              children: <Widget>[
                ListTile(
                  leading: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        FontAwesomeIcons.userAlt,
                        size: ScreenUtil().setHeight(50),
                      ),
                    ],
                  ),
                  title: Text(
                    "Name",
                    style: TextStyle(
                        fontSize: ScreenUtil().setHeight(35),
                        color: Colors.black),
                  ),
                  subtitle: Text("Zuher Abud"),
                ),//Name
                Divider(
                  indent: 70.0,
                  color: Colors.grey,
                  height: -0.0,
                ),
                ListTile(
                  leading: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        Icons.email,
                        size: ScreenUtil().setHeight(50),
                      ),
                    ],
                  ),
                  title: Text(
                    "Email",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: ScreenUtil().setHeight(35),
                    ),
                  ),
                  subtitle: Text(emailid),
                ),//Email
                Divider(
                  indent: 70.0,
                  color: Colors.grey,
                  height: -0.0,
                ),
                ListTile(
                  leading: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        FontAwesomeIcons.microphone,
                        size: ScreenUtil().setHeight(50),
                      ),
                    ],
                  ),
                  title: Text(
                    "Support",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: ScreenUtil().setHeight(35),
                    ),
                  ),
                  subtitle: Text("Rate Us!"),
                ),//Support
                Divider(
                  indent: 70.0,
                  color: Colors.grey,
                  height: -0.0,
                ),
                ListTile(
                  leading: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        Icons.perm_contact_calendar,
                        size: ScreenUtil().setHeight(50),
                      ),
                    ],
                  ),
                  title: Text(
                    "Contact Us",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: ScreenUtil().setHeight(35),
                    ),
                  ),
                  subtitle: Text("Incase Of Any Help You can Contact us."),
                ),//Contact Us
                Divider(
                  indent: 70.0,
                  color: Colors.grey,
                  height: -0.0,
                ),
                ListTile(
                  leading: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(
                        Icons.feedback,
                        size: ScreenUtil().setHeight(50),
                      ),
                    ],
                  ),
                  title: Text(
                    "Terms & Privicy Policy",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: ScreenUtil().setHeight(35),
                    ),
                  ),
                  subtitle:
                      Text("Terms and priviy and policy can be read here."),
                ),//Terms and Privacy Policy
                Divider(
                  indent: 70.0,
                  color: Colors.grey,
                  height: -0.0,
                ),
                GestureDetector(
                  onTap:(){
                    _signOut();
                  },
                  child: ListTile(
                    leading: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(
                          FontAwesomeIcons.signOutAlt,
                          size: ScreenUtil().setHeight(50),
                        ),
                      ],
                    ),
                    title: Text(
                      "Logout",
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: ScreenUtil().setHeight(35),
                      ),
                    ),
                  ),
                ),//Logout when pressed signs user out
              ],
            ),
          )
        ],
      ),
    );
  }
  _signOut() async {
    await _firebaseAuth.signOut();
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => CheckAuth()),);
    SharedPreferences.getInstance().then((SharedPreferences value) {
      setState(() {
        value.setBool("islogin", false);
        value.setBool("isteacher", false);
        Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => CheckAuth()),
              (Route<dynamic> route) => false,
        );
      });
    });
  }// when logout button pressed
}
