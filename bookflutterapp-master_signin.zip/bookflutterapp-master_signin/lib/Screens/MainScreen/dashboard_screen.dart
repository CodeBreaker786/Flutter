import 'dart:ui';
import 'package:bookreadingapp/Screens/chapter_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

class DashboardScreen extends StatelessWidget {
  //these are chapter numbers that get created using listbuilder in chapter screen when selecting specific card in review screen
  // we will be getting this chapter numbers from api this is for testing
  List<int> list1 = [1, 2, 3, 4, 7, 8, 12];
  List<int> list2 = [5, 9, 10, 11, 13];
  List<int> list3 = [14, 15, 16, 17, 18];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: ScreenUtil().setHeight(25),
                  vertical: ScreenUtil().setHeight(15)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text("Progress", style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: ScreenUtil().setHeight(24)),),//Progress Text
                  Container(
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          height: ScreenUtil().setHeight(280),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              //total words and hard words
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Container(
                                        margin: EdgeInsets.only(right: 5),
                                        height: ScreenUtil().setHeight(70),
                                        width: ScreenUtil().setHeight(7),
                                        decoration: BoxDecoration(
                                            color: Colors.lightBlue,
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(ScreenUtil()
                                                    .setHeight(5)))),
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            "Total Words",
                                            style: TextStyle(
                                                fontSize:
                                                    ScreenUtil().setHeight(24),
                                                fontWeight: FontWeight.w500),
                                          ),
                                          SizedBox(
                                            height: 8,
                                          ),
                                          Row(
                                            children: <Widget>[
                                              Text(
                                                "1000",
                                                style: TextStyle(
                                                    fontSize: ScreenUtil()
                                                        .setHeight(24),
                                                    fontWeight:
                                                        FontWeight.w400),
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Text(
                                                "Words",
                                                style: TextStyle(
                                                    fontSize: ScreenUtil()
                                                        .setHeight(24),
                                                    fontWeight:
                                                        FontWeight.w400),
                                              )
                                            ],
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Container(
                                        margin: EdgeInsets.only(right: 5),
                                        height: ScreenUtil().setHeight(70),
                                        width: ScreenUtil().setHeight(7),
                                        decoration: BoxDecoration(
                                            color: Colors.lightBlue,
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(5))),
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            "Hard Words",
                                            style: TextStyle(
                                                fontSize:
                                                    ScreenUtil().setHeight(24),
                                                fontWeight: FontWeight.w500),
                                          ),
                                          SizedBox(
                                            height: 8,
                                          ),
                                          Row(
                                            children: <Widget>[
                                              Text(
                                                "153",
                                                style: TextStyle(
                                                    fontSize: ScreenUtil().setSp(
                                                        100,
                                                        allowFontScalingSelf:
                                                            false),
                                                    fontWeight:
                                                        FontWeight.w400),
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Text(
                                                "Words",
                                                style: TextStyle(
                                                    fontSize: ScreenUtil()
                                                        .setHeight(24),
                                                    fontWeight:
                                                        FontWeight.w400),
                                              )
                                            ],
                                          )
                                        ],
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              //Circular Percentage indicator + round pic
                              Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                ),
                                child: CircularPercentIndicator(
                                  radius:
                                      MediaQuery.of(context).size.height * .15,
                                  lineWidth: 14.0,
                                  animation: true,
                                  percent: 0.65,
                                  center: CircleAvatar(
                                    backgroundImage:
                                        AssetImage("images/books/Book1.jpg"),
                                    radius: 46,
                                  ),
                                  footer: Text(
                                    (0.65 * 100).toString() + " %",
                                    style: TextStyle(
                                        color: Colors.grey.shade400,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  circularStrokeCap: CircularStrokeCap.round,
                                  progressColor: Colors.lightBlue,
                                ),
                              )
                            ],
                          ),
                        ),
                        Divider(
                          color: Colors.grey.shade200,
                          height: 2,
                          thickness: 2,
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: ScreenUtil().setHeight(30),
                              vertical: ScreenUtil().setHeight(24)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Column(
                                children: <Widget>[
                                  Text(
                                    "Chapters",
                                    style: TextStyle(
                                        fontSize: ScreenUtil().setHeight(24),
                                        fontWeight: FontWeight.w500),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  LinearPercentIndicator(
                                    width: 100.0,
                                    lineHeight:
                                        MediaQuery.of(context).size.height *
                                            .02,
                                    center: Text(
                                      "6 Left",
                                      style: TextStyle(
                                          fontSize: ScreenUtil().setHeight(20),
                                          color: Colors.white),
                                    ),
                                    percent: 0.85,
                                    backgroundColor: Colors.grey.shade300,
                                    progressColor: Colors.lightBlue,
                                  ),
                                ],
                              ),
                              Column(
                                children: <Widget>[
                                  Text(
                                    "Words",
                                    style: TextStyle(
                                        fontSize: ScreenUtil().setHeight(24),
                                        fontWeight: FontWeight.w500),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  LinearPercentIndicator(
                                    width: 100.0,
                                    lineHeight:
                                        MediaQuery.of(context).size.height *
                                            .02,
                                    center: Text(
                                      "20 Left",
                                      style: TextStyle(
                                          fontSize: ScreenUtil().setHeight(20),
                                          color: Colors.white),
                                    ),
                                    percent: 0.85,
                                    backgroundColor: Colors.grey.shade300,
                                    progressColor: Colors.lightBlue,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                    margin: EdgeInsets.only(top: ScreenUtil().setHeight(15)),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(
                          ScreenUtil().setHeight(100),
                        ),
                        topLeft: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                        bottomLeft: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                        bottomRight: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade400,
                          blurRadius: 5,
                          spreadRadius: .2,
                        ),
                      ],
                    ),
                  ), //Container under Progress Text
                  SizedBox(
                    height: 40,
                  ), //Empty Space separating Progress Group and Review Group
                  Text("Review", style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: ScreenUtil().setHeight(24),
                    ),),//Review Text
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text("Word Category", style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: ScreenUtil().setHeight(26),
                                color: Colors.grey.shade700)),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              OutlineButton(
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(
                                    ScreenUtil().setHeight(6),
                                  ))),
                                  padding: EdgeInsets.all(0),
                                  onPressed: () {},
                                  child: Container(
                                    height: ScreenUtil().setHeight(60),
                                    child: ClipRRect(
                                        borderRadius:
                                            new BorderRadius.circular(4.0),
                                        child: Image.asset(
                                          "images/total_words.png",
//                                          fit: BoxFit.fitHeight,
                                        )),
                                  )),
                              OutlineButton(
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(
                                    ScreenUtil().setHeight(6),
                                  ))),
                                  padding: EdgeInsets.all(0),
                                  onPressed: () {},
                                  child: Container(
                                    height: ScreenUtil().setHeight(60),
                                    child: ClipRRect(
                                        borderRadius: new BorderRadius.circular(
                                          ScreenUtil().setHeight(6),
                                        ),
                                        child: Image.asset(
                                            "images/hard_words.png")),
                                  )),
                            ],
                          ),
                        ),
                        Text("Days Category", style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: ScreenUtil().setHeight(26),
                                color: Colors.grey.shade700)),
                        Container(
                          margin: EdgeInsets.only(top: 5),
                          height: ScreenUtil().setHeight(180),
                          child: Center(
                            child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount: 3,
                                itemBuilder: (context, index) {
                                  return GestureDetector(
                                    onTap: () {
                                      print("click");
                                      index == 0 ? Navigator.push(context,
                                          MaterialPageRoute(builder: (context) =>
                                              ChapterScreen(chapterList: list1, cardNumber: 1,
                                              ),
                                          ),
                                      )
                                      : index == 1 ? Navigator.push(context,
                                            MaterialPageRoute(builder: (context) =>
                                                ChapterScreen(chapterList: list2, cardNumber: 2,
                                                ),
                                            ),
                                      )
                                      : Navigator.push(context,
                                            MaterialPageRoute(builder: (context) =>
                                                ChapterScreen(chapterList: list3, cardNumber: 3,
                                                ),
                                            ),
                                      );
                                    },
                                    child: Container(
                                      child: Center(
                                        child: Text(
                                          index == 0
                                              ? "Less Than 2 Days"
                                              : index == 1
                                                  ? "Less Than 8 Days "
                                              "More Than 2 Days"
                                                  : "More Than 8 Days",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              fontSize:
                                                  ScreenUtil().setHeight(24),
                                              color: Colors.white),
                                        ),
                                      ),
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 5),
                                      margin: EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 5),
                                      height:
                                          MediaQuery.of(context).size.height *
                                              .1,
                                      width: MediaQuery.of(context).size.width *
                                          .24,
                                      decoration: BoxDecoration(
                                        color: index == 0
                                            ? Color(0xFF439984)
                                            : index == 1
                                                ? Color(0xFFEA8833)
                                                : Color(0xFFFF1D00),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(10),
                                          topLeft: Radius.circular(10),
                                          bottomLeft: Radius.circular(10),
                                          bottomRight: Radius.circular(10),
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey.shade400,
                                            blurRadius: 5,
                                            spreadRadius: .2,
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                }),
                          ),
                        )
                      ],
                    ),
                    width: double.infinity,
                    margin: EdgeInsets.only(top: 8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(
                          ScreenUtil().setHeight(100),
                        ),
                        topLeft: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                        bottomLeft: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                        bottomRight: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade400,
                          blurRadius: 5,
                          spreadRadius: .2,
                        ),
                      ],
                    ),
                  )//Container under Review Text
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
