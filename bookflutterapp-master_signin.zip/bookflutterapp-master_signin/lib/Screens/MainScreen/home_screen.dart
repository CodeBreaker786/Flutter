import 'package:bookreadingapp/Screens/MainScreen/profile_screen.dart';
import 'package:bookreadingapp/Screens/swipe/swipe_feed_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:bookreadingapp/Screens/MainScreen/dashboard_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,

      body: _index == 0 ? HomeScreenBody() : _index == 1 ? DashboardScreen() : ProfileScreen(),
      bottomNavigationBar: CurvedNavigationBar(
        height: 70,
        animationDuration: Duration(milliseconds: 400),
        backgroundColor: Colors.transparent.withOpacity(0.0),
        buttonBackgroundColor: Colors.white,
        color: Colors.lightBlue,
        index: 0,
        items: <Widget>[
          Icon(
            FontAwesomeIcons.home,
            size: ScreenUtil().setHeight(50),
            color: _index == 0 ? Colors.lightBlue : Colors.white,
          ),
          Icon(
            FontAwesomeIcons.book,
            size: ScreenUtil().setHeight(50),
            color: _index == 1 ? Colors.lightBlue : Colors.white,
          ),
          Icon(
            FontAwesomeIcons.userAlt,
            size: ScreenUtil().setHeight(50),
            color: _index == 2 ? Colors.lightBlue : Colors.white,
          ),
        ],
        onTap: (index) {
          setState(() {
            _index = index;
          });
        },
      ),
      appBar: AppBar(
        automaticallyImplyLeading: false,//?????????????????????
        backgroundColor: Colors.lightBlue,
        brightness: Brightness.dark,//????????????????????
        title: Text(
          _index == 0 ? "Home" : _index == 1 ? "Dashboard" : "Profile",
          style: TextStyle(
              color: Colors.white,
              fontSize: ScreenUtil().setHeight(30),
              fontWeight: FontWeight.bold),
        ),
        centerTitle: false,
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: 20),
            child: GestureDetector(
              onTap: () {
                //Navigator.pushNamed(context, "/Studentstatistic");
              },
              child: Icon(
                _index == 2 ? FontAwesomeIcons.bell : FontAwesomeIcons.graduationCap,
                size: ScreenUtil().setHeight(50),
                color: Colors.white,
              ),
            ),
          )
        ],
      ),

    );
  }
}

class HomeScreenBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: ScreenUtil().setHeight(25),
                  vertical: ScreenUtil().setHeight(15)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "Book",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: ScreenUtil().setHeight(25)),
                  ),//Book Text
                  Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: ScreenUtil().setHeight(20),
                        vertical: ScreenUtil().setHeight(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text("Brief Info",
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: ScreenUtil().setHeight(24),
                                color: Colors.black)),
                        Text(
                            "Here will be some brief info about the book that has been slected .Here will be some brief info about the book that has been slected . ",
                            style: TextStyle(
                                fontWeight: FontWeight.w300,
                                fontSize: ScreenUtil().setHeight(24),
                                color: Colors.black))
                      ],
                    ),
                    margin: EdgeInsets.symmetric(
                        vertical: ScreenUtil().setHeight(15)),
//              height: 100,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(20),
                        topLeft: Radius.circular(5),
                        bottomLeft: Radius.circular(5),
                        bottomRight: Radius.circular(5),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade400,
                          blurRadius: 5,
                          spreadRadius: .2,
                        ),
                      ],
                    ),
                  ),//First Container under Book Text
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: ScreenUtil().setHeight(25),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.symmetric(
                                vertical: ScreenUtil().setHeight(25),
                              ),
                              child: Row(
//                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Container(
                                    margin: EdgeInsets.only(right: 5),
                                    height: ScreenUtil().setHeight(70),
                                    width: ScreenUtil().setHeight(7),
                                    decoration: BoxDecoration(
                                        color: Colors.lightBlue,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(
                                                ScreenUtil().setHeight(5)))),
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        "Total Chapters",
                                        style: TextStyle(
                                            fontSize:
                                                ScreenUtil().setHeight(24),
                                            fontWeight: FontWeight.w500),
                                      ),
                                      SizedBox(
                                        height: 8,
                                      ),
                                      Row(
                                        children: <Widget>[
                                          Text(
                                            "30",
                                            style: TextStyle(
                                                fontSize:
                                                    ScreenUtil().setHeight(24),
                                                fontWeight: FontWeight.w400),
                                          ),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          Text(
                                            "Chapters",
                                            style: TextStyle(
                                                fontSize:
                                                    ScreenUtil().setHeight(24),
                                                fontWeight: FontWeight.w400),
                                          )
                                        ],
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: ScreenUtil().setHeight(20),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: ScreenUtil().setHeight(20)),
                              child: Row(
                                children: <Widget>[
                                  Container(
                                    margin: EdgeInsets.only(right: 5),
                                    height: ScreenUtil().setHeight(70),
                                    width: ScreenUtil().setHeight(7),
                                    decoration: BoxDecoration(
                                        color: Colors.lightBlue,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(
                                                ScreenUtil().setHeight(5)))),
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        "Total Words",
                                        style: TextStyle(
                                            fontSize:
                                                ScreenUtil().setHeight(24),
                                            fontWeight: FontWeight.w500),
                                      ),
                                      SizedBox(
                                        height: 8,
                                      ),
                                      Row(
                                        children: <Widget>[
                                          Text(
                                            "1000",
                                            style: TextStyle(
                                                fontSize:
                                                    ScreenUtil().setHeight(24),
                                                fontWeight: FontWeight.w400),
                                          ),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          Text(
                                            "Words",
                                            style: TextStyle(
                                                fontSize:
                                                    ScreenUtil().setHeight(24),
                                                fontWeight: FontWeight.w400),
                                          )
                                        ],
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.lightBlue)),
                          child: CircleAvatar(
                            backgroundImage: AssetImage("images/books/Book1.jpg"),
                            radius: ScreenUtil().setHeight(90),
                          ),
                        )
                      ],
                    ),
                    margin: EdgeInsets.only(
                      top: ScreenUtil().setHeight(15),
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(
                          ScreenUtil().setHeight(100),
                        ),
                        topLeft: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                        bottomLeft: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                        bottomRight: Radius.circular(
                          ScreenUtil().setHeight(10),
                        ),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade400,
                          blurRadius: 5,
                          spreadRadius: .2,
                        ),
                      ],
                    ),
                  ),//Second Container under Book Text
                ],
              ),
            ),//The Containers above Scrollable Chapters
            Container(
              height: ScreenUtil().setHeight(420),
              child: ListView.builder(
                itemCount: 31,
                scrollDirection: Axis.horizontal,
                itemBuilder: (BuildContext context, int index) {
                  return Container(
                    margin: EdgeInsets.only(
                        top: ScreenUtil().setHeight(10),
                        left: ScreenUtil().setHeight(20),
                        bottom: ScreenUtil().setHeight(15)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            Text(
                              "Chapter $index",
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: ScreenUtil().setHeight(24),
                                  color: Colors.black),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                              "Chapter Title here",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: ScreenUtil().setHeight(28),
                                  color: Colors.black),
                            ),
                          ],
                        ),
                        index == 0 ? Text("0 % Complete", style: TextStyle(fontSize: ScreenUtil().setHeight(24), color: Colors.grey, fontWeight: FontWeight.bold),) : Text("Lock",
                                style: TextStyle(
                                    fontSize: ScreenUtil().setHeight(24),
                                    color: Colors.grey,
                                    fontWeight: FontWeight.bold)),
                        index == 0 ? ButtonTheme(
                                height: ScreenUtil().setHeight(60),
                                minWidth: ScreenUtil().setHeight(150),
                                child: RaisedButton(
                                    shape: StadiumBorder(),
                                    color: Colors.lightBlue,
                                    child: Text(
                                      "START",
                                      style: TextStyle(
                                          fontSize: ScreenUtil().setHeight(24),
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white),
                                    ),
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  SwipeFeedPage(
                                                    totalWords: [
                                                      [
                                                        "Good",
                                                        "Bad",
                                                        "money",
                                                        "luck"
                                                      ],
                                                      [
                                                        "Good in chinese here",
                                                        "bad in chines here",
                                                        "money in chines here",
                                                        "luck in chines here"
                                                      ],
                                                      [
                                                        "Good in chinese here englis",
                                                        "bad in chines here english",
                                                        "mony in chines here englsh",
                                                        "luck in chines here english"
                                                      ]
                                                    ],
                                                  )));
                                    }),
                              ) : Icon(
                                FontAwesomeIcons.lock,
                                size: ScreenUtil().setHeight(100),
                                color: Colors.grey,
                              )
                      ],
                    ),
                    width: ScreenUtil().setHeight(200),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(ScreenUtil().setHeight(70)),
                        topLeft: Radius.circular(ScreenUtil().setHeight(10)),
                        bottomLeft: Radius.circular(ScreenUtil().setHeight(10)),
                        bottomRight:
                            Radius.circular(ScreenUtil().setHeight(10)),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade400,
                          blurRadius: 5,
                          spreadRadius: .2,
//                            offset: Offset(10.0, 8.0)),
                        )
                      ],
                    ),
                  );
                },
              ),
            )//The Scrollable Chapters
          ],
        ),
      ),
    );
  }
}
