import 'package:bookreadingapp/Screens/MainScreen/home_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ChooseBook extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade300,
      appBar: AppBar(
        title: Text("Choose Book", style: TextStyle(color: Colors.white, fontSize: ScreenUtil().setHeight(30), fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: BookPageBody(),
    );
  }
}
class BookPageBody extends StatefulWidget {
  @override
  _BookPageBodyState createState() => _BookPageBodyState();
}
class _BookPageBodyState extends State<BookPageBody> {
  // we will be getting the books for each language from api this is for testing
  int totalbooks = 5;
  @override
  Widget build(BuildContext context) {
    // Create a grid with 2 columns. If you change the scrollDirection to
    // horizontal, this produces 2 rows.
    return GridView.count(
      shrinkWrap: true,
      childAspectRatio: (100 / 160),
      crossAxisCount: 2,
      children: List.generate(5, (index) {
        return Container(
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              CupertinoButton(
                padding: EdgeInsets.all(0),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
                },
                child: Image.asset("images/books/Book$index.jpg"),
              ),
              Container(
                color: Colors.white,
                child: Padding(
                  padding: EdgeInsets.only(
                      left: ScreenUtil().setHeight(5),
                      top: ScreenUtil().setHeight(5),
                      bottom: ScreenUtil().setHeight(5)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text('Book Title Here', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.black, fontSize: ScreenUtil().setHeight(24),),),
                          GestureDetector(
                              onTap: () {},
                              child: Icon(
                                FontAwesomeIcons.ellipsisV,
                                size: 20,
                              ),
                          ),
                        ],
                      ),//Book Title Text and Three Dots Icons
                      Text('Author Name', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey, fontSize: ScreenUtil().setHeight(24),),),//Author Name Text
                    ],
                  ),
                ),
              ),//The container of every Book
            ],
          ),
        );
      }),
    );
  }
}
