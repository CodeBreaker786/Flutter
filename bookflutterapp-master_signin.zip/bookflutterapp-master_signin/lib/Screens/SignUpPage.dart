import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'SigninPage.dart';
import 'choose_launguage.dart';

class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => new _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _email, _password;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      appBar: new AppBar(automaticallyImplyLeading: false,title: new Text("SignUp")),
      body: SingleChildScrollView(
        child: Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                new Image(
                  image:  new AssetImage("images/illustration/File2.png"),
                  width: 180.0,
                  height: 150.0,
                ),
                new Text(
                  "Register",
                  style: new TextStyle(fontWeight: FontWeight.bold),
                ),
                new Padding(padding: const EdgeInsets.only(top: 50.0)),
                new ListTile(
                  leading: const Icon(Icons.email),
                  title: new TextFormField(
                    validator: (input) {
                      if (input.isEmpty) {
                        return 'Enter Email ';
                      }
                    },
                    decoration: InputDecoration(labelText: 'Email Id'),
                    onSaved: (input) => _email = input,
                  ),
                ),
                new ListTile(
                  leading: const Icon(Icons.lock),
                  title: new TextFormField(
                    validator: (input) {
                      if (input.length < 6) {
                        return 'Enter six digit password';
                      }
                    },
                    decoration: InputDecoration(labelText: 'Password'),
                    onSaved: (input) => _password = input,
                    obscureText: true,
                  ),
                ),
                ButtonTheme(
                  height: 40.0,
                  minWidth: 200.0,
                  child: RaisedButton(
                      onPressed: signUp,
                      child: Text('Sign up', style: new TextStyle(color: Colors.white),),
                      color: Colors.lightBlue,
                      shape: new RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(30.0))),
                ),
                new Text(
                  "OR",
                ),
                new  FlatButton(
                    onPressed: signinpage,
                    child: Text('Sign in', style: new TextStyle(color: Colors.black),),
                    color: Colors.transparent,
                    shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(30.0))),
              ],
            )),
      ),
    );
  }

  void signUp() async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      try {
        AuthResult result = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: _email, password: _password);
        FirebaseUser user = result.user;
        print("fsfsfsfsf$user");
        print(user);
        Navigator.pushAndRemoveUntil(context,
            MaterialPageRoute(builder: (context) => Launguage()), (Route<dynamic> route) => false,);
      } catch (e) {

        Fluttertoast.showToast(
            msg: e.message,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }
    }
  }
  void signinpage() async {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => SigninPage()),);
  }

}