//chapter screen to navigate from review in dashboard screen

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

Color mehronColor = Color(0xff921C11);
Color deepGreenColor = Color(0xff2E423E);
Color deepAmberColor = Color(0xffB73F1C);

class ChapterScreen extends StatelessWidget {
  final List<int> chapterList;
  final int cardNumber;

  ChapterScreen({this.chapterList, this.cardNumber});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cardNumber == 1 ? Colors.lightGreenAccent : cardNumber == 2 ? Colors.amberAccent : Colors.redAccent,
      appBar: AppBar(
        automaticallyImplyLeading: false,//????????????????????????????
        backgroundColor: cardNumber == 1 ? deepGreenColor : cardNumber == 2 ? deepAmberColor : mehronColor,
        centerTitle: false,//??????????????????????????//
        title: Text(cardNumber == 1 ? "Less Than 2 Days" : cardNumber == 2 ? "Less Than 4 Days" : "More Than 8 Days",
          style: TextStyle(
              color: Colors.white,
              fontSize: ScreenUtil().setHeight(26),
              fontWeight: FontWeight.bold),
        ),
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: ScreenUtil().setWidth(15)),
            child: ButtonTheme(
              child: RawMaterialButton(
//                fillColor: Colors.transparent,
                constraints: BoxConstraints(
                    minHeight: ScreenUtil().setHeight(30),
                    minWidth: ScreenUtil().setHeight(40)),
                shape: CircleBorder(),
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(color: Colors.white, width: 2),
                      shape: BoxShape.circle),
                  child: Icon(
                    Icons.close,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          )
        ],
      ),
      //difference in color appbar and backround of each tile
      body: ReviewChapter(chapters: chapterList, cardNumber: cardNumber,),
    );//Setting Scafold Properties
  }
}

class ReviewChapter extends StatefulWidget {
  final int cardNumber;
  final List<int> chapters;


  ReviewChapter({this.chapters, this.cardNumber});

  @override
  _ReviewChapterState createState() => _ReviewChapterState();
}

class _ReviewChapterState extends State<ReviewChapter> {
  Color greenSelectedColor = Color(0xff439984);
  Color greenUnSelectedColor = Color(0xff87A596);
  Color amberSelectedColor = Color(0xFFEA8833);
  Color amberUnSelectedColor = Color(0xFFECB13D);
  Color redSelectedColor = Color(0xFFFF1D00);
  Color redUnSelectedColor = Color(0xFFB3605D);

  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: ListView.builder(
          itemCount: widget.chapters.length,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                setState(() {
                  selectedIndex = index;
                });
              },
              child: Container(
                child: Padding(
                  padding: EdgeInsets.only(left: ScreenUtil().setHeight(40)),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text("Chapter " + widget.chapters[index].toString(),
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: ScreenUtil().setHeight(54),
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                height: ScreenUtil().setHeight(90),
                decoration: BoxDecoration(
                    color: widget.cardNumber == 1 ? selectedIndex == index ? greenSelectedColor : greenUnSelectedColor : widget.cardNumber == 2 ? selectedIndex == index ? amberSelectedColor : amberUnSelectedColor : selectedIndex == index ? redSelectedColor : redUnSelectedColor,
                    border: Border(
                      top: BorderSide(color: Colors.black),
                      bottom: BorderSide(color: Colors.black),
                    )//Border for each Tile
                ),//selected and unselected tiles color
              ),
            );
          }),
      height: MediaQuery.of(context).size.height,
      width: double.infinity,
    );
  }
}
