import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

class SwipeFeedPage extends StatefulWidget {
  final List<List<String>> totalWords;
  SwipeFeedPage({this.totalWords});
  @override
  _SwipeFeedPageState createState() => new _SwipeFeedPageState();
}

class _SwipeFeedPageState extends State<SwipeFeedPage> {
  List<String> firstCardStrings = new List();
  List<String> secondCardStrings = new List();
  List<String> firstCardEngStringstemp = new List();
  List<String> firstCardChineseStringstemp = new List();
  List<String> firstCardChineseEngStringstemp = new List();

  void updateCardString() {
    setState(() {
      firstCardEngStringstemp.add(firstCardStrings[0]);
      firstCardChineseStringstemp.add(firstCardStrings[1]);
      firstCardChineseEngStringstemp.add(firstCardStrings[2]);

      firstCardStrings[0] = secondCardStrings[0];
      firstCardStrings[1] = secondCardStrings[1];
      firstCardStrings[2] = secondCardStrings[2];

      if (widget.totalWords[0].isEmpty) {
        secondCardStrings[0] = firstCardEngStringstemp[0];
        secondCardStrings[1] = firstCardChineseStringstemp[0];
        secondCardStrings[2] = firstCardChineseEngStringstemp[0];

        firstCardEngStringstemp.removeAt(0);
        firstCardChineseStringstemp.removeAt(0);
        firstCardChineseEngStringstemp.removeAt(0);
      } else {
        secondCardStrings[0] = widget.totalWords[0][0];
        secondCardStrings[1] = widget.totalWords[1][0];
        secondCardStrings[2] = widget.totalWords[2][0];

        widget.totalWords[0].removeAt(0);
        widget.totalWords[1].removeAt(0);
        widget.totalWords[2].removeAt(0);
      }
    });
  }

  void populate(
      List firstCard, List secondCard, List<List<String>> totalWords) {
    print(totalWords[0][0]);
    firstCard.add(totalWords[0][0]);
    firstCard.add(totalWords[1][0]);
    firstCard.add(totalWords[2][0]);
    secondCard.add(totalWords[0][1]);
    secondCard.add(totalWords[1][1]);
    secondCard.add(totalWords[2][1]);
    totalWords[0].removeAt(0);
    totalWords[1].removeAt(0);
    totalWords[2].removeAt(0);
    totalWords[0].removeAt(0);
    totalWords[1].removeAt(0);
    totalWords[2].removeAt(0);
  }

  bool showAlignmentCards = false;
  bool isHardWord = false;

  @override
  void initState() {
    populate(firstCardStrings, secondCardStrings, widget.totalWords);
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        elevation: 0.0,
        centerTitle: true,
        backgroundColor: Colors.grey.shade300,
        actions: <Widget>[
          new IconButton(
              onPressed: () {},
              icon: new Icon(Icons.pause, color: Colors.grey)),
        ],
      ),
      backgroundColor: Colors.grey.shade300,
      body: Center(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Container(
                height: ScreenUtil().setHeight(900),
                child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Positioned(
                      top: ScreenUtil().setHeight(10),//set y axis
                      child: Card(
                        elevation: 8,
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        child: Container(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.all(ScreenUtil().setHeight(10)),
                                height: ScreenUtil().setHeight(90),
                                child: Image.asset("images/Icons/hardicon.png",color: isHardWord ? Colors.red : Colors.grey,),
                              ),
                              Container(
                                height: ScreenUtil().setHeight(610),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                      secondCardStrings[0],
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: ScreenUtil().setHeight(36),
                                          fontWeight: FontWeight.w500),
                                    ),
                                    Text(
                                      secondCardStrings[1],
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: ScreenUtil().setHeight(36),
                                          fontWeight: FontWeight.w500),
                                    ),
                                    Text(
                                      secondCardStrings[2],
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: ScreenUtil().setHeight(36),
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          width: ScreenUtil().setHeight(450),
                          height: ScreenUtil().setHeight(700),
                        ),
                      ),
                    ),//Behind Card
                    Positioned(
                      top: ScreenUtil().setHeight(20),//set y axis
                      child: Draggable(
                        onDragEnd: (value) {setState(() {updateCardString();});},
                        childWhenDragging: Container(),
                        feedback: Card(
                          elevation: 5,
                          color: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          child: Container(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                CupertinoButton(
                                  padding: EdgeInsets.all(0),
                                  onPressed: () {},
                                  child: Container(
                                    padding: EdgeInsets.only(
                                        top: ScreenUtil().setHeight(10)),
                                    height: ScreenUtil().setHeight(100),
                                    child: Container(
                                      child: Image.asset("images/Icons/hardicon.png", color: isHardWord ? Colors.red : Colors.grey,),
                                    ),
                                  ),
                                ),
                                Container(
                                  height: ScreenUtil().setHeight(620),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text(
                                        firstCardStrings[0],
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize:
                                            ScreenUtil().setHeight(36),
                                            fontWeight: FontWeight.w500),
                                      ),
                                      Text(
                                        firstCardStrings[1],
                                        style: TextStyle(
                                            color: Colors.grey,
                                            fontSize:
                                            ScreenUtil().setHeight(36),
                                            fontWeight: FontWeight.w500),
                                      ),
                                      Text(
                                        firstCardStrings[2],
                                        style: TextStyle(
                                            color: Colors.grey,
                                            fontSize:
                                            ScreenUtil().setHeight(36),
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            width: ScreenUtil().setHeight(520),
                            height: ScreenUtil().setHeight(740),
                          ),
                        ),
                        child: Card(
                          elevation: 6,
                          color: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          child: Container(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                CupertinoButton(
                                  padding: EdgeInsets.all(0),
                                  onPressed: () {
                                    setState(() {
                                      if (isHardWord) {
                                        isHardWord = false;
                                      } else {
                                        isHardWord = true;
                                      }
                                    });
                                  },
                                  child: Container(
                                    padding: EdgeInsets.only(
                                        top: ScreenUtil().setHeight(10)),
                                    height: ScreenUtil().setHeight(100),
                                    child: Container(
                                      child: Image.asset("images/Icons/hardicon.png", color: isHardWord ? Colors.red : Colors.grey),
                                    ),
                                  ),
                                ),
                                Container(
                                  height: ScreenUtil().setHeight(620),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text(
                                        firstCardStrings[0],
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize:
                                            ScreenUtil().setHeight(36),
                                            fontWeight: FontWeight.w500),
                                      ),
                                      Text(
                                        firstCardStrings[1],
                                        style: TextStyle(
                                            color: Colors.grey,
                                            fontSize:
                                            ScreenUtil().setHeight(36),
                                            fontWeight: FontWeight.w500),
                                      ),
                                      Text(
                                        firstCardStrings[2],
                                        style: TextStyle(
                                            color: Colors.grey,
                                            fontSize:
                                            ScreenUtil().setHeight(36),
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            width: ScreenUtil().setHeight(500),
                            height: ScreenUtil().setHeight(735),
                          ),
                        ),
                      ),
                    ),//Front Card
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  LinearPercentIndicator(
                    width: MediaQuery.of(context).size.width / 3.5,
                    lineHeight: MediaQuery.of(context).size.height * .025,
                    percent: 0.65, // here put the percent
                    backgroundColor: Colors.white,
                    progressColor: Colors.lightBlue,
                  ),
                  LinearPercentIndicator(
                    width: MediaQuery.of(context).size.width / 3.5,
                    lineHeight: MediaQuery.of(context).size.height * .025,
                    percent: 0.0, // here percent for the next 10 words
                    backgroundColor: Colors.white,
                    progressColor: Colors.lightBlue,
                  ),
                  LinearPercentIndicator(
                    width: MediaQuery.of(context).size.width / 3.5,
                    lineHeight: MediaQuery.of(context).size.height * .025,
                    percent: 0.0, // percent for final reound
                    backgroundColor: Colors.white,
                    progressColor: Colors.lightBlue,
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
