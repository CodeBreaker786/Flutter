import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CustomTextField extends StatelessWidget {
  final String hintText;
  final IconData leadaingIcon;
  final bool securePassword;
  final Function onChange;
  final Function validation;
  CustomTextField(
      {this.hintText,
      this.leadaingIcon,
      this.securePassword,
      this.validation,
      @required this.onChange});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: TextFormField(
        validator: validation,
        onChanged: onChange,
        obscureText: securePassword,
        style: TextStyle(
          color: Colors.grey.shade700,
          fontWeight: FontWeight.bold,
          fontSize: ScreenUtil().setHeight(24),
        ),
        decoration: InputDecoration(
            labelText: hintText,
            border: OutlineInputBorder(),
            prefixIcon: Icon(leadaingIcon),
            hintText: hintText,
            hintStyle: TextStyle(
                color: Colors.grey,
                fontSize: ScreenUtil().setHeight(24),
                fontWeight: FontWeight.bold)),
      ),
    );
  }
}

class TitleForLoginSignup extends StatelessWidget {
  final String titleText;
  TitleForLoginSignup({this.titleText});
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(
          titleText,
          style: TextStyle(
              fontSize: ScreenUtil().setHeight(30),
              fontWeight: FontWeight.bold,
              color: Colors.black),
        ),
        SizedBox(
          height: 10,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "Not a memeber yet?",
              style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: ScreenUtil().setHeight(28),
                  fontWeight: FontWeight.bold),
            ),
            Text("  SignUp",
                style: TextStyle(
                    color: Colors.green,
                    fontSize: ScreenUtil().setHeight(28),
                    fontWeight: FontWeight.bold))
          ],
        )
      ],
    );
  }
}
