import 'package:bookreadingapp/Screens/chapter_screen.dart';
import 'package:bookreadingapp/Screens/choose_launguage.dart';
import 'package:flutter/material.dart';
import 'package:bookreadingapp/Screens/MainScreen/home_screen.dart';
import 'package:flutter/services.dart';
import 'Screens/CheckAuth.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: "/",
      routes: {
        "/": (context) => CheckAuth(),
        "/home": (context) => HomeScreen(),
        "/chapters": (context) => ChapterScreen(),
        "/launguage": (context) => Launguage(),
        "/dashboard": (context) => DashboardScreen(),

      },
    );
  }
}
