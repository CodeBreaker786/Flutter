import 'package:bookreadingapp/Screens/choose_language_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'SigninPage.dart';
import 'choose_launguage.dart';

class CheckAuth extends StatefulWidget {
  @override
  _CheckAuthState createState() => new _CheckAuthState();
}

class _CheckAuthState extends State<CheckAuth> {
  bool isLoggin = false;
  bool isTeacher = false;
  bool loading = true;
  var users;

  void getSharedPref() async {
    SharedPreferences.getInstance().then((SharedPreferences value) {
      setState(() {
        isLoggin = value.getBool("islogin") ?? false;
        isTeacher = value.getBool("isteacher") ?? false;
        loading = false;
      });
    });
  }

  @override
  void initState() {
    getSharedPref();
    FirebaseAuth.instance.currentUser().then((user) => user != null
        ? setState(() {
            isLoggin = true;
            users = user;
          })
        : null);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 2688, height: 1242);
    return loading
        ? Container(
            child: CircularProgressIndicator(),
            height: 50,
            width: 50,
          )
        : isLoggin ? ChooseLanguage() : SigninPage();
  }
}
